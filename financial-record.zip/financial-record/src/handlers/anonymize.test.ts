// tests/handlers/anonymize.test.ts

import { anonymizeData } from '../../src/utils/anonymize';

test('anonymizeData should hash userId', () => {
    const data = { userId: '12345' };
    const anonymized = anonymizeData(data);
    expect(anonymized.userId).not.toBe('12345');
});