// src/handlers/processTransaction.ts

import { APIGatewayProxyHandler } from 'aws-lambda';
import { anonymizeData } from '../utils/anonymize';
import { encryptData } from '../utils/cryptoUtils';
import { calculateRisk } from '../utils/riskAssessment';
import { storeData } from '../utils/s3Utils';

export const processTransaction: APIGatewayProxyHandler = async (event) => {
    try {
        const body = JSON.parse(event.body);

        // Validate input data
        if (!body.transactionId || !body.amount || !body.userId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Invalid input data' })
            };
        }

        // Anonymize data
        const anonymizedData = anonymizeData(body);

        // Encrypt data
        const encryptedData = encryptData(anonymizedData);

        // Calculate risk
        const riskScore = calculateRisk(anonymizedData);

        // Store data
        await storeData(encryptedData, riskScore);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Transaction processed successfully' })
        };
    } catch (error) {
        console.error('Error processing transaction:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' })
        };
    }
};