// src/utils/cryptoUtils.ts

import crypto from 'crypto';

const AES_KEY = 'your-aes-key-here'; // Use a secure key management system

export const encryptData = (data: any) => {
    const cipher = crypto.createCipher('aes-256-cbc', AES_KEY);
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
};