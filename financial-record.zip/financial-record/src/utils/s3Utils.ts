// src/utils/s3Utils.ts

import AWS from 'aws-sdk';

const s3 = new AWS.S3();

export const storeData = async (data: any, riskScore: number) => {
    const params = {
        Bucket: 'your-bucket-name',
        Key: `transactions/${Date.now()}.json`,
        Body: JSON.stringify({ data, riskScore }),
        ContentType: 'application/json'
    };

    await s3.putObject(params).promise();
};