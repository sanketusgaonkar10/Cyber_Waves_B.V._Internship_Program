// src/utils/anonymize.ts

import crypto from 'crypto';

export const anonymizeData = (data: any) => {
    const hash = crypto.createHash('sha256');
    hash.update(data.userId);
    data.userId = hash.digest('hex');
    return data;
};